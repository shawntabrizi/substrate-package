# Template Node

A new SRML-based Substrate node, ready for hacking.
